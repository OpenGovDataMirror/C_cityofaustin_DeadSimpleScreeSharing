var STATUS = null;
var SERVER;

if(localStorage['screensharing_server_name'] === 'undefined') {
  SERVER = 'deadsimplescreensharing.com';
  localStorage['screensharing_server_name'] = 'deadsimplescreensharing.com';
} else {
  SERVER = localStorage['screensharing_server_name'];
}


var uniqueID = null;
var globalSocket;

function connect() {
  //var socket = io.connect("dss.mohammedlakkadshaw.com")
  //var socket = io.connect("http://evening-lake-9962.herokuapp.com/");
  var socket = io.connect(SERVER);

  socket.on("status", function(data) {
    STATUS = data.data;
  });

  socket.emit('getMeIn');

  socket.on("youAreIn", function(data) {
    chrome.browserAction.setBadgeText({text:"ON"});

    var newSocket = io.connect(SERVER+"/"+data.id);
    globalSocket = newSocket;
    uniqueID = data.id;

  });
}



function send(data) {
  if((typeof data == 'object') && (data.__proto__ !== Blob.prototype)) {
    data = JSON.stringify(data)
  }
  if(typeof socket === 'undefined') {
    socket = globalSocket;
  }
    socket.emit('stream', {'data':data})
}

function convertDataURIToBlob(dataURI, mimetype) {
  if (!dataURI) {
    return new Uint8Array(0);
  }

  var BASE64_MARKER = ';base64,';
  var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
  var base64 = dataURI.substring(base64Index);
  var raw = window.atob(base64);
  var uInt8Array = new Uint8Array(raw.length);

  for (var i = 0; i < uInt8Array.length; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }

  return new Blob([uInt8Array], {type: mimetype});
}
