var IMG_FORMAT = 'jpeg';
var IMG_MIMETYPE = 'image/' + IMG_FORMAT;
var IMG_QUALITY = 80
var SEND_INTERVAL_MS = 1000;

var socket = null;
var intervalId = null;
var VIEWER_TAB_ID = null;

chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 100]});

function captureAndSendTab() {
   var opts = {
    format: IMG_FORMAT,
    quality: IMG_QUALITY
  };

 
 chrome.tabs.captureVisibleTab(null, opts, function(dataUrl) {
   	console.log("Sending..");
    //send(convertDataURIToBlob(dataUrl, IMG_MIMETYPE));
  	send(dataUrl);
  });
}

function transmitData() {
	if(!intervalId) {
		 connect();
	}
	chrome.browserAction.setBadgeText({text:"ON"});
	intervalId = setInterval(function() {
		console.log("Sending");
		captureAndSendTab();
	}, SEND_INTERVAL_MS);
}

function mutationTransmit() {
	if(!intervalId) {
		socket = connect();
		intervalId = true;
	}
	
	chrome.extension.onMessage.addListener(function(request, sender) {
		//var type = JSON.parse(request);
		console.log("Message Recieved\n");
		if(request.updateUI && socket !== null) {
			captureAndSendTab();
		}
	});

	// chrome.tabs.onUpdated.addListener(function(id, changeInfo, tab) {
	// 	captureAndSendTab();	
	// });
	
	// chrome.tabs.onCreated.addListener(function(id, changeInfo, tab) {
	// 	captureAndSendTab();	
	// });
	
	// chrome.tabs.onActivated.addListener(function(id, changeInfo, tab) {
	// 	captureAndSendTab();	
	// });
	// chrome.tabs.onHighlighted.addListener(function(id, changeInfo, tab) {
	// 	captureAndSendTab();	
	// });
	
	chrome.tabs.onUpdated.addListener(captureAndSendTab);
	chrome.tabs.onCreated.addListener(captureAndSendTab);
	chrome.tabs.onActivated.addListener(captureAndSendTab);
	chrome.tabs.onHighlighted.addListener(captureAndSendTab);
}

function disconnect() {
	
	socket = undefined;
	intervalId = false;
	uniqueID = null;
	
	globalSocket.emit('release', {id:uniqueID});
	globalSocket.on('disconnect_client', function() {
		globalSocket.disconnect();
		globalSocket = undefined;
	});
	
	chrome.browserAction.setBadgeText({text:""});

	//removing all the listerns
	chrome.tabs.onActivated.removeListener(captureAndSendTab);
	chrome.tabs.onUpdated.removeListener(captureAndSendTab);
	chrome.tabs.onCreated.removeListener(captureAndSendTab);
	chrome.tabs.onHighlighted.removeListener(captureAndSendTab);
}
