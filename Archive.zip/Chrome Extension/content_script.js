console.log("Script Loaded");
(function (window){
 
  var p = {};
  var m = {
    registerObserver: function() {
      if (typeof(window.WebKitMutationObserver) == "undefined") return;
      
      p.observer = new window.WebKitMutationObserver(function(mutationRecords) {
        console.log("Observer Called");
        chrome.extension.sendMessage({updateUI:true})
      });
      
      p.observer.observe(window.document, {
        subtree: true,  // observe the subtree rooted at myNode
        childList: true,  // include information childNode insertion/removals
        attribute: false  // include information about changes to attributes within the subtree
      });
    }
  };
  m.registerObserver();

  //register scroll handler
  window.document.addEventListener('scroll', function() {
      if(typeof window.debounceScroll !== 'undefined') {
        return;
      } else {
        window.debounceScroll = setTimeout(function() {
          chrome.extension.sendMessage({updateUI:true});
          delete window.debounceScroll;
        },1000);
        chrome.extension.sendMessage({updateUI:true})
        console.log("Updating UI");
      }
  });

})(window)