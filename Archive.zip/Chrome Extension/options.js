function save_options() {
	var textbox = document.getElementById("server_name");
	var server_name = textbox.value;
	localStorage['screensharing_server_name'] = server_name;
	loadCurrent();
}

function restore_options () {
	localStorage['screensharing_server_name'] = 'deadsimplescreensharing.com';
	loadCurrent();
}

function loadCurrent() {
	body = document.getElementById('current_server')
	body.innerHTML = (localStorage['screensharing_server_name']);

}

document.addEventListener('DOMContentLoaded', loadCurrent);

document.querySelector('#restore').addEventListener('click', restore_options);

document.querySelector('#save').addEventListener('click', save_options);