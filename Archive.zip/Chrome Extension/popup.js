$(function() {
  $("#disconnect").click(function  () {
    bg = chrome.extension.getBackgroundPage();
   
    $(".well").html("");
    $("#status").text("disconnected");
    $(this).hide();
    //clearing the timer
    if(window.uniqueIDTimer !== 'undefined') {
        clearInterval(window.uniqueIDTimer);
    }
    bg.disconnect();
});
    console.log("Document Loaded");
    bg = chrome.extension.getBackgroundPage();
    bg.mutationTransmit();

    window.uniqueIDTimer =  setInterval(function() {
        id = bg.uniqueID;
        server = bg.SERVER;
        if(id !== null) {
            $("#status").text(bg.STATUS);
            $(".well").html("Your screen is avaliable at:<br/><br/><a href='http://"+server+"/"+id+"'>http://"+server+"/"+id+"</a><br /> <br/> Your session id: <code>"+id+"</code>");
            $("#disconnect").show();
            window.clearInterval(window.uniqueIDTimer);
            delete window.uniqueIDTimer;
        }
    }, 100);

});