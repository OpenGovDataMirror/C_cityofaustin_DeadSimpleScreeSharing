DeadSimpleScreeSharing
======================

A simple screen sharing app written in node.js that allows you to share you screen with anyone right from your browser